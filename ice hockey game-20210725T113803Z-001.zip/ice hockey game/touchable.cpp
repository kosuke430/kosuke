#include <tchar.h>
#include <windows.h>
#define D3D_DEBUG_INFO
#include <stdlib.h>
#include <math.h>
#include <d3dx9.h>
#include <XAudio2.h>
#include <vector>
#include <list>

#include "../include/WindowManager.h"
#include "../include/ars.h"
#include "reactive.h"
#include "touchable.h"

using namespace std;


Event* Touchability::produceEvent(float x, float y, Event::Kind k)
{
	return new TouchEvent( x, y, k, Gx, Gy );
}

bool Touchability::check()
{
	static Texture2D txtr;	

	ARSG* g = subject->GetARSG();
	static int fake = txtr.Init(g, sizex, sizey);

	unsigned int pixel_count;

	g->Draw(subject, &txtr);
	ARSC::and(&txtr, &txtr, hitArea, 0x10101010);
	
	float testGx, testGy;
	ARSC::getCG(&testGx, &testGy, &pixel_count, &txtr);

	bool touching = pixel_count > threshold;

	if (touching) {
		Gx = testGx;
		Gy = testGy;
	}	

	return touching;
}


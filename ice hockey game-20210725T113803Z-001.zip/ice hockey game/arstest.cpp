#include <tchar.h>
#include <windows.h>
#define D3D_DEBUG_INFO
#include <stdlib.h>
#include <math.h>
#include <d3dx9.h>
#include <XAudio2.h>
#include <vector>
#include <list>
#include <iostream>

#include "../include/WindowManager.h"
#include "../include/ars.h"
#include "reactive.h"
#include "touchable.h"
#include "reflective.h"
#include "arstest.h"

//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: The application's entry point
//-----------------------------------------------------------------------------

using namespace std;

void subtract_mask(Texture* result, Texture* bg, Texture* src, DWORD border);

UINT MainLoop(WindowManager *winmgr)
{
	ShowDebugWindow();

	//for debug(1/2)
	//Window window2;
	//winmgr->RegisterWindow(&window2);

	//ARSG arsgd(window2.hWnd, sizex, sizey, true);
	//Texture2D debug(&arsgd, sizex, sizey);

	Window window;
	winmgr->RegisterWindow(&window);

	ARSG g{ window.hWnd, sizex, sizey, true };
	g.SetBackgroundColor(255, 0, 0, 0);

	Light light{ &g };
	g.Register(&light);

	ARSD d;
	d.Init();
	d.AttachCam(0);
	d.StartGraph();

	Texture hitArea{ &g, sizex, sizey};
	Texture stored { &g, sizex, sizey};
	Texture2D source{ &g, sizex, sizey };
	Texture2D ground{ &g,L"ground2.png"};
	//Plate2D pac{ &g,L"pac.jpeg",L"pac.jpeg",&hitArea,100};
	Ball pacmove{ &g,L"pac.jpeg",&hitArea,100 };
	pacmove.SetScale(1.5f, 1.5f, 1.5f);
	pacmove.SetPosition(220, 170, 0.0f, GL_ABSOLUTE);
	g.Register(&source);
	g.Register(&ground);
	g.RegisterShape(&pacmove);
	
	



	InputHandler *keyIn = window.GetInputHandler();

	while (!d.GetCamImage(&stored));	

	while (!winmgr->WaitingForTermination()){
		if (keyIn->GetKeyTrig('A'))
			d.GetCamImage(&stored);
		d.GetCamImage(&source);
		if (keyIn->GetKeyTrig('Q')) break;
			
		subtract_mask(&hitArea,&stored,&source,0x20202020);	
				
		Movable::move_all();
		Reactivity::all_react();				
		//for debug(2/2)
		//debug = hitArea;
		//arsgd.Draw(&debug);
		g.Draw();
		
	}
	d.StopGraph();
	return 0;
}

inline void subtract_mask(Texture* result, Texture* backgrnd, Texture* src, DWORD border)
{
	ARSC::diff(result,backgrnd,src,border);
	ARSC::monochrome(result,result);
	ARSC::thresholding(result,result,border);
}

inline void Bounce::onBegin(Event* p)
{	
	SetVelocity(		
		(p->x - static_cast<TouchEvent*>(p)->gx) * -0.05f,
		(-(p->y - static_cast<TouchEvent*>(p)->gy)) * -0.05f,
		0.0f );
}

inline void Reflect::onBegin(Event*)
{
	(orientation ? target->velocity.y : target->velocity.x) *= -0.5f;
}


void Blush::track()
{
	Shape* trg = dynamic_cast<Shape*>(target);
	if (trg) {
		blushed.SetPosition(trg->GetPosition());
		blushed.SetScale(trg->GetScale());

		D3DXMATRIX rot;
		trg->GetRotation(&rot);
		blushed.SetRotation(&rot);
	}
}
D3DXMATRIX trans;
inline void Blush::onBegin(Event*) 
{
	track(); 
}
inline void Blush::onEnd(Event*)
{
	blushed.SetScale(0, 0, 0);
}
inline void Blush::onContinue(Event*)
{
	track();
}
inline void Ball::move()
{
	VECTOR2D c = getPosition2D();

	if (c.x < 0&&velocity.x<0) {
		if (c.y>180&&c.y <280) {
			++left;
			SetPosition(220, 170, 0.0f, GL_ABSOLUTE);
			cout << left << ":" << right << endl;

		}
		velocity.x *=-1.0;
	}
	if (c.y <0&&velocity.y<0) {
		velocity.y *=-1.0;
	}
	if (c.x >540&&velocity.x>0) {
		if (c.y >180&&c.y<280) {
			++right;
			SetPosition(220, 170, 0.0f, GL_ABSOLUTE);
			cout << left << ":" << right << endl;
		}
		velocity.x *=-1.0;
	}
	if (c.y > 340&&velocity.y>0) {
		velocity.y *=-1.0;
	}
	Movable::move();
	//cout << c.y << " " << c.x << endl;
}



void Plate2D::move()
{
	Movable::move();
}



int APIENTRY _tWinMain(
	HINSTANCE hInstance
	, 	HINSTANCE // hPrevInstance
	, 	LPTSTR // lpCmdLine
	, 	int // nCmdShow
)
{
	WindowManager program(hInstance, &MainLoop);
#ifdef DEBUG
    MessageBox(NULL,L"OK?",TEXT(APPNAME), NULL);
#endif
    return 0;
}

#include <tchar.h>
#include <windows.h>
#define D3D_DEBUG_INFO
#include <stdlib.h>
#include <math.h>
#include <d3dx9.h>
#include <XAudio2.h>
#include <vector>
#include <list>

#include "../include/WindowManager.h"
#include "../include/ars.h"
#include "reactive.h"
#include "reflective.h"


using namespace std;
const int ground_height = 50;

bool ReflectivitySide::check()
{
	VECTOR2D c = getPosition2D(subject);
	return c.x < 0 || c.x > sizex;
}

bool ReflectivityGround::check()
{
	VECTOR2D c = getPosition2D(subject);
	return c.y > sizey - ground_height  && dynamic_cast<Movable*>(subject)->velocity.y < 0	;
}





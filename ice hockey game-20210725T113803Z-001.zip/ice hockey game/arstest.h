#pragma once

#ifndef _DEBUG
#pragma comment(lib, "../lib/ARS.lib")
#pragma comment(lib, "../lib/WML.lib")
#else
#pragma comment(lib, "../lib/ARSd.lib")
#pragma comment(lib, "../lib/WMLd.lib")
#endif

#include <string>

#define _CRT_SECURE_NO_WARNINGS

#define CLASSNAME "ARSTEST"
#define APPNAME "ARSTEST"


class Bounce : public Reaction{
public:
	Bounce(Movable* target) : Reaction{ target }{}
	void onBegin(Event* ev) override;

};

class Blush : public Reaction{	
	void track();
	D3DXVECTOR3 original_scale;
public:	
	Texture2D blushed,pacmove;
	Blush(Movable* target, wchar_t fln[])
		: Reaction{ target }
		, blushed{ dynamic_cast<Shape*>(target)->GetARSG(), fln}
	{
		blushed.SetScale(0,0,0);
	}
	void onBegin(Event*) override;
	void onEnd(Event*) override;
	void onContinue(Event*) override;


};

class Reflect : public Reaction{

	bool orientation; //true:vertical, false:horizontal
public:
	Reflect(Movable* target, bool ori) :Reaction{ target }, orientation{ ori }{}
	void onBegin(Event*) override;
};
class Plate2D : public Texture2D, public Movable {
	Blush blush;
	Touchability touchability;
public:
	Plate2D(ARSG* _g, wchar_t fln[], wchar_t fln2[], Texture* hA, unsigned int threshold)
		: Texture2D{ _g, fln }
		, Movable{ 0.1f, 0, 0 }
		, blush{ this, fln2 }
		, touchability{ this, hA, threshold,{ &blush } }
	{}

	void move() override;

	Texture* getBlushedTexture() { return &blush.blushed; }
};

class Ball : public Texture2D, public Movable{
	Bounce bounce{ this };
	Reflect reflect_h{ this ,false };
	Reflect reflect_v{ this ,true };
	ReflectivitySide side_reflective{ this, {&reflect_h} };
	ReflectivityGround ground_reflective{ this, {&reflect_v} };
	Touchability touchable;
	int right = 0, left = 0;
public:
	Ball(ARSG* _g, wchar_t fln[], Texture* hA, unsigned int threshold)
		: Texture2D{ _g, fln }
		, Movable{ 0.0f, 0.0f, 0 }
		, touchable{ this, hA, threshold, {&bounce} }
	{ }	
	void move() override;
};


#pragma once


//���T�C�h�̔���
class ReflectivitySide : public Reactivity{
	bool check() override;
public:
	ReflectivitySide(Shape* sbj
		, std::initializer_list<Reaction*> rctns = std::initializer_list<Reaction*>())
		: Reactivity{ sbj, rctns } {}
};

//�n�ʂ̔���
class ReflectivityGround : public Reactivity{
	bool check() override;
public:
	ReflectivityGround(Shape* sbj
		, std::initializer_list<Reaction*> rctns = std::initializer_list<Reaction*>())
		: Reactivity{ sbj, rctns } {}
};

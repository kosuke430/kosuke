#include <tchar.h>
#include <windows.h>
#define D3D_DEBUG_INFO
#include <stdlib.h>
#include <math.h>
#include <d3dx9.h>
#include <XAudio2.h>
#include <vector>
#include <list>

#include "../include/WindowManager.h"
#include "../include/ars.h"
#include "reactive.h"

using namespace std;

//�ŐV�̏��������ăC�x���g�����o���A��Ԃ��X�V����
Event::Kind State::captureEvent(bool touching)
{	
	if (on){
		if (touching){
			return Event::STAY;
		}
		else {
			on = false;
			return Event::LEAVE;
		}
	}
	else{
		if (touching){
			on = true;
			return Event::ENTER;
		}
		else{
			return Event::NONE;
		}
	}
}
/* hacker's version:
// event   on     condition
// NONE		0		0
// TOUCH	0		1
// LEAVE	1		0
// STAY		1		1
Event State::captureEvent(bool condition)
{
	int ev = on << 1 | condition<<0;
	if (on^condition) on = condition;
	return (Event)ev;
}
*/


void Reaction::SetVelocity(float x, float y, float z)
{
	target->velocity.x = x;
	target->velocity.y = y;
	target->velocity.z = z;
}
void Reaction::SetVelocity(D3DXVECTOR3 v){ target->velocity = v; }
D3DXVECTOR3 Reaction::GetVelocity(){ return target->velocity; }




void Reactivity::locate(float* x, float* y)
{
	VECTOR2D c = getPosition2D(subject);
	*x = c.x;
	*y = c.y;
}

void Reactivity::dispatch(Event* ev)
{		
	switch (ev->kind){
	case Event::NONE:  for (Reaction* r : reactions) r->onNotStarted(ev); break;
	case Event::ENTER: for (Reaction* r : reactions) r->onBegin(ev); break;
	case Event::LEAVE: for (Reaction* r : reactions) r->onEnd(ev); break;
	case Event::STAY:  for (Reaction* r : reactions) r->onContinue(ev); break;
	default:;
	}
}
Event* Reactivity::produceEvent(float x, float y, Event::Kind k)
{
	return new Event(x,y,k);
}


//�C�x���g�����o������ꏊ�Ǝ�ނ���肵�ăC�x���g�I�u�W�F�N�g�𐶐��A
//����������Ƀ��X�i�[�̃R�[���o�b�N���Ă�
void Reactivity::react()
{	
	float x, y;
	locate(&x,&y);	
	Event::Kind k =state.captureEvent(check());
	Event* ev=produceEvent(x, y, k);
	dispatch(ev);
	delete ev;
}


list<Reactivity*> Reactivity::all;
void Reactivity::all_react(list<Reactivity*>* ts)
{
	for (auto t : *ts) t->react();
}

void Reactivity::addReaction(Reaction* r)
{
	reactions.push_back(r);
}

void Reactivity::removeReaction(Reaction* r)
{
	reactions.remove(r);
}

VECTOR2D Movable::getPosition2D()
{
	return ::getPosition2D(dynamic_cast<Shape*>(this));
}
std::list<Movable*> Movable::all;

void Movable::move_all(std::list<Movable*>* lst)
{
	for (auto m : *lst) m->move();
}
void Movable::move()
{
	dynamic_cast<Shape*>(this)->SetPosition(velocity, GL_RELATIVE);
}



VECTOR2D getPosition2D(Shape* shape)
{
	static VECTOR2D c;

	D3DXVECTOR3 p = shape->GetPosition();
	if (dynamic_cast<Texture2D*>(shape))
		return VECTOR2D{ p.x,p.y };
	else
		return shape->GetARSG()->Convert3Dto2D(&c, p);
}

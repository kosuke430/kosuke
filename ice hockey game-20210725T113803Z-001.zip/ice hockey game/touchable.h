#pragma once


struct TouchEvent : public Event{
	float gx;
	float gy;

	TouchEvent(float x, float y, Event::Kind k, float gx_, float gy_)
		: Event{ x, y, k }, gx{ gx_ }, gy{ gy_ }{}
};


//�v���[���[�Ƃ̐ڐG������
class Touchability : public Reactivity{
	Texture* hitArea;
	unsigned int threshold;
	float Gx;
	float Gy;
	bool check() override;
	Event* produceEvent(float x, float y, Event::Kind k) override;
public:	
	Touchability(Shape* sbj, Texture* hA, unsigned int thrd
		, std::initializer_list<Reaction*> rctns = std::initializer_list<Reaction*>())
		: Reactivity{ sbj, rctns }
		, hitArea{hA},threshold{ thrd }
	{}
};











